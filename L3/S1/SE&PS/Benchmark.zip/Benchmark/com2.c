#include <stdlib.h>
#include <unistd.h>
int 
main() 
{
  sleep(1) ; 
  exit(1) ;
}

