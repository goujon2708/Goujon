#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

// clear && clear && gcc tempsmoy.c -o tempsmoy
// ./tempsmoy 1000 "ls | ./poubelle.txt" 5





int comparaison(const void * a, const void * b) 
{
	int const *a2 = a;
	int const *b2 = b;
	
	return *a2 - *b2;
}




void initTab( int tab[] , int tailleTab , int initialisateur ) 
{
	int i;
	for( i=0 ; i<tailleTab ; i++ )
		tab[i] = initialisateur;
}




void initMatrice( int * matrice[] , int tailleTab , int initialisateur ) 
{
	int i, j;
	
	for( i=0 ; i<tailleTab ; i++ )
		for( j=0 ; j<2 ; j++ )
			matrice[i][j] = initialisateur;
}








int main( int argc , char * argv[] ) 
{
	if( argc != 4 ) 
	{
		printf( "Erreur : Usage --> %s <nbExecutions> <commande> <nbProcessus>\n" , argv[0] );
		exit(-1);
	}
	
	int nbExecutions = atoi(argv[1]);	// K => nb d'exécutions
	int nbProcessus = atoi(argv[3]);	// N => nb de processus 
	int nbFils;
	
	int tabTemps[nbProcessus];
	int nbExecutionsFaites;
	
	struct timeval tpsDepart;
	struct timeval tpsArrivee;
	
	int tpsTotal;
	int cr = 0;
	int tpsRetenu;
	int estPere = 1;
	int premierTempsBon = 0;
	
	
	int tube[nbProcessus][2];
	
	// création des tubes en fonction du nombre de processus 
	for( nbFils=0 ; nbFils<nbProcessus ; nbFils++ )
		pipe(tube[nbFils]);
	
	
	
	// Initialisation des tableaux
	initTab(tabTemps, nbProcessus, 0);
	
	nbFils = 0;
	
	
	
	
	// BOUCLE PRINCIPALE SUR LES N PROCESSUS
	while( nbFils<nbProcessus && estPere ) 
	{
		switch( estPere = fork() ) 
		{
			case -1:
				printf( "Erreur fork\n" );
				exit(-1);
				
				
			
			case 0:
				printf( "Fils n° : %i\n" , nbFils );
				
				// Les fils ecrivent seulement
				close( tube[nbFils][0] );
				
				
				if( gettimeofday( &tpsDepart , NULL ))
					printf( "Erreur recuperation temps\n" );
				
				
				
				
				// Execution de la commande
				for( nbExecutionsFaites=0 ; nbExecutionsFaites<nbExecutions && WIFEXITED(cr) ; nbExecutionsFaites++ )
					cr = system(argv[2]);
				
				
				
				
				if( gettimeofday( &tpsArrivee , NULL ))
					printf("Erreur recuperation temps\n" );
				
				
				
				// calcul du temps d'exécution
				tpsTotal = tpsArrivee.tv_sec * 1000 + tpsArrivee.tv_usec / 1000 -
							tpsDepart.tv_sec * 1000 + tpsDepart.tv_usec / 1000;




				if( cr ) 
				{
					printf("Interruption du fils n°%i lors de l'execution de %s : ", nbFils, argv[2]);
					
					
					if( WEXITSTATUS(cr) > 128 )
						printf("SIGNAL");
					
					else
						printf("EXIT");
					
					tpsTotal = -cr;
					
					write( tube[nbFils][1] , &tpsTotal , sizeof(int) );
					
					printf("\n");
				} 
				
				
				else
					// Ecriture du dit "temps d'execution"
					write( tube[nbFils][1] , &tpsTotal , sizeof(int) );
				
				
				
				close( tube[nbFils][1] );
				
				exit(0);
		}
		
		nbFils++;
	}
	
	
	
	for( nbFils=0 ; nbFils<nbProcessus ; nbFils++ ) 
	{
		close( tube[nbFils][1] );
		
		read( tube[nbFils][0] , &(tabTemps[nbFils]) , sizeof(int) );
		
		close( tube[nbFils][0] );
	}
	
		
	
	
	
	// ---- AFFICHAGE DES RESULTATS ---- //
	
	
	printf("\n\nAVANT TRI\n");
	
	for( nbFils=0 ; nbFils<nbProcessus ; nbFils++ ) 
	{
		if( tabTemps[nbFils] <= 0 ) 
		{
			printf( "Erreur execution du fils n°%i\n" , nbFils );
			premierTempsBon++;
		} 
		
		else
			printf( "Temps n°%i : %i\n" , nbFils , tabTemps[nbFils] );
	}
	
	
	
	
	// Tri du tableau
	qsort( tabTemps , nbProcessus , sizeof(int) , comparaison );
	
	
	
	
	printf("\n\nAPRES TRI\n");
	
	for( nbFils=0 ; nbFils<nbProcessus ; nbFils++ ) 
	{
		if(tabTemps[nbFils] > 0)
			printf("Temps n°%i : %i" , nbFils , tabTemps[nbFils] );		
		
		else 
		{
			cr = ( -tabTemps[nbFils] ) / 256;
			
			if(cr > 128)
				printf(" Interruption par le signal %i\n", cr - 128);
			
			switch(cr) 
			{
				case 127 :
					printf( " --> Commande non trouvee\n" );
					break;
				
				case 1 :
					printf( " --> exit(1)\n" );
					break;
			
				case 0 :
					printf( " --> Interruption du processus avant qu'il ne puisse envoyer quoi que ce soit\n" );
					break;
			
				default :
					printf( " --> Interruption par le signal %i\n", cr );
					break;
			}
		}
		
		printf("\n");
	}
	
	
	tpsRetenu = tabTemps[ ( nbProcessus+premierTempsBon ) /2 ];
	
	
	
	if(tpsRetenu > 0) 
	{
		printf("\n\nTemps retenu : %i ms\n", tpsRetenu);
		printf("\"%s\" nécessite %i ms pour être exécutée\n" , argv[2] , tpsRetenu / nbExecutions );
	} 
	
	
	else
		printf("Aucune execution n'a abouti correctement\n");
		
	
	return 0;
}