#include <unistd.h>
#include <stdlib.h>
int 
main() 
{
  sleep(1) ; 
  exit(0) ;
}
